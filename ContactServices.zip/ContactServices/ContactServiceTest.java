package module3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
public class ContactServiceTest {

/*
* The following tests exercise the ContactService class.
* In each test, a new service is created with default values for each field.
* Then the service is requested to make some change to the list of contacts and the result
* is tested to ensure the actual field matches what is expected.
*
* Because each contact that gets created has a new automatically assigned contactID,
* and the tests are run based on that contactID, the order in which the tests are run depend
* on the value of each contactID. Therefore, the @Order annotation is used to keep the tests
* in a specific order.
*
* For evidence that the contactID is correct for each test, uncomment the service.displayContactList();
* prior to each assertion so that the records are displayed on the console for error checking.
*/
@Test
@DisplayName("Test to Update First Name.")
@Order
	void testUpdateFirstName() {
	ContactService service = new ContactService();
	service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
	service.updateFirstName("Sven", "0");
	//service.displayContactList();
	assertEquals("Sven",service.getContact("0").getFirstName(), "First name was not updated.");
}

@Test
@DisplayName("Test to Update Last Name.")
@Order
void testUpdateLastName() {
ContactService service = new ContactService();
service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
service.updateLastName("Shirley", "2");
//service.displayContactList();
assertEquals("Shirley",service.getContact("2").getLastName(), "Last name was not updated.");
}

@Test
@DisplayName("Test to update phone number.")
@Order
void testUpdatePhoneNumber() {
ContactService service = new ContactService();
service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
service.updateNumber("5555550000", "4");
//service.displayContactList();
assertEquals("5555550000",service.getContact("4").getNumber(), "Phone number was not updated.");
}

@Test
@DisplayName("Test to update address.")
@Order
void testUpdateAddress() {
ContactService service = new ContactService();
service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
service.updateAddress("555 Nowhere Ave", "6");
//service.displayContactList();
assertEquals("555 Nowhere Ave",service.getContact("6").getAddress(), "Address was not updated.");
}

@Test
@DisplayName("Test to ensure that service correctly deletes contacts.")
@Order
void testDeleteContact() {
ContactService service = new ContactService();
service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
service.deleteContact("8");
//Ensure that the contactList is now empty by creating a new empty contactList to compare it with
ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
//service.displayContactList();
assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
}

@Test
@DisplayName("Test to ensure that service can add a contact.")
@Order
void testAddContact() {
ContactService service = new ContactService();
service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
//service.displayContactList();
assertNotNull(service.getContact("9"), "Contact was not added correctly.");
}

}